function [edges, MIs] = chow_liu_gauss(Sigma,n)

d = length(Sigma);

A=chol(Sigma);

x = A'*randn(4,n);

% C = zeros(d,d);
% for i = 1:d
%     for j = i:d
%         C(i,j) = 1/n*dot(x(i,:), x(j,:));
%     end
% end

C = 1/n*x*x';

c = zeros(d,d);
MIs = zeros(d,d);

for i = 1:d
    for j = i+1:d
        c(i,j) = C(i,j)/sqrt(C(i,i)*C(j,j));
        MIs(i,j) = 1/2*log(1/(1-c(i,j)^2));
    end
end


MIs=MIs+MIs.';

edges = prim(-MIs);