%%% Implementing chain and star graphs for d even
d = 10;

% Create a d \times d chain covariance matrix
rho = linspace(.9,.1,d-1);

% random_vector = rand(d-1,1);
% [sorted, order] = sort(random_vector);
% rho = rho(order);
rho = fliplr(rho);

Sigma_chain = zeros(d);

for i = 1:d
    for j = i:d
        if (i == j)
            Sigma_chain(i,j) = .5;
        else
            Sigma_chain(i,j) = prod(rho(i:j-1));
        end
    end
end
Sigma_chain = Sigma_chain + Sigma_chain';

% Create a d \times d intermediate (hybrid star and chain) covariance matrix
Sigma_hyb = zeros(d);
for i = 1:d/2
    for j = i:d/2
        Sigma_hyb(i,j) = prod(rho(i:j-1));
    end
end
for i = d/2+1:d
    Sigma_hyb(1,i) = rho(i-1);
end
for i = 2:d/2
    for j = d/2+1:d
        Sigma_hyb(i, j) = prod(rho(1:i-1))*rho(j-1);
    end
end
for i = d/2+1:d
    for j = i+1:d
        Sigma_hyb(i, j)  = rho(i-1)*rho(j-1);
    end
end
for i = 1:d
    Sigma_hyb(i,i) = .5;
end

Sigma_hyb = Sigma_hyb+Sigma_hyb';

% Create a d \times d star covariance matrix
Sigma_star = zeros(d);
Sigma_star(2:end,1) = rho';
Sigma_star(1,2:end) = rho;

for i = 1:d
    Sigma_star(i,i) = 1;
end

for i = 2:d
    for j = 2:d
        if(j ~= i)
            Sigma_star(i,j) = rho(i-1)*rho(j-1);
        end
    end
end

% Generate samples from chain and star
nn = round(logspace(log10(5e2),log10(5e4),8));

% Ground truths
struc_chain = zeros(d-1, 2);
struc_hyb = zeros(d-1, 2);
struc_star = zeros(d-1, 2);

for i = 1:d-1
    struc_chain(i, 1) = i; struc_chain(i, 2) = i+1;
    struc_star(i, 1) = 1; struc_star(i, 2) = i+1;
    if(i<d/2)
        struc_hyb(i,1) = i; struc_hyb(i, 2) = i+1;
    else
        struc_hyb(i, 1) = 1; struc_hyb(i, 2) = i+1;
    end
end

M = 3e6;
hit_chain = zeros(M,length(nn));
hit_hyb = zeros(M,length(nn));
hit_star = zeros(M,1);

tic
for m = 1:M

    for k = 1:length(nn)

        n = nn(k);

        A = chol(Sigma_chain);
        x = randn(d,n);
        x = A'*x;
        emp_chain = 1/n*x*x';

        B = chol(Sigma_star);
        y = randn(d,n);
        y = B'*y;
        emp_star = 1/n*y*y';

        C = chol(Sigma_hyb);
        z = randn(d,n);
        z = C'*z;
        emp_hyb = 1/n*z*z';

        corr_chain = emp_chain./sqrt(diag(emp_chain)*diag(emp_chain)');
        corr_star = emp_star./sqrt(diag(emp_star)*diag(emp_star)');
        corr_hyb = emp_hyb./sqrt(diag(emp_hyb)*diag(emp_hyb)');

        for i = 1:d
            corr_chain(i,i) = 0;
            corr_star(i,i) = 0;
            corr_hyb(i,i) = 0;
        end

        MIs_chain = 1/2*log(1./(1-corr_chain.^2));
        MIs_star = 1/2*log(1./(1-corr_star.^2));
        MIs_hyb = 1/2*log(1./(1-corr_hyb.^2));

        chain_edges = prim(-MIs_chain);
        star_edges = prim(-MIs_star);
        hyb_edges = prim(-MIs_hyb);

        hit_chain(m,k) = correctedges(chain_edges, struc_chain);
        hit_star(m,k) = correctedges(star_edges, struc_star);
        hit_hyb(m,k) = correctedges(hyb_edges, struc_hyb);

    end
    %toc
    if(mod(m,1e5)==0)
        disp(['Iteration number: ' num2str(m) ', Time: ' num2str(toc)]);
    end
end

perr_chain = 1-sum(hit_chain)/M;
perr_star = 1-sum(hit_star)/M;
perr_hyb = 1-sum(hit_hyb)/M;

 