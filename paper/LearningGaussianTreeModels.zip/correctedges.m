function [hit,hitrate] = correctedges(phat_edges,p_edges)

% Compare with actual tree
hit=0;
n=length(phat_edges)+1;

for i = 1:n-1
    p=phat_edges(i,:);
    for j = 1:n-1
        if(norm(p-p_edges(j,:))==0 || norm([p(2) p(1)]-p_edges(j,:))==0)
            hit = hit+1;
        end
    end
end
hitrate=hit/(n-1);

if(hitrate<1)
    hit = 0;
else 
    hit = 1;
end