function L_F = listdecodingfinal(n,p,c,b,Poly)
global PCparams;
N= 2^n; K= ceil(c*N); r= ceil(b*sqrt(N));
v= (rand(K,1)>0.5);
gen = comm.CRCGenerator(Poly, 'ChecksumsPerFrame',1);
u = step(gen,v);
initPC(N,K+r,'BEC',p);
x=pencode(u);
y=OutputOfChannel(x,'BEC',p);
y_hat= Deletion(y);
U_hat= ldecode(y_hat,p);
List=list(U_hat);
Final_list=final(List, Poly);
F=size(Final_list,1);
if F == 0
    t=0;
else
t= ismember(transpose(u), Final_list, 'rows');
end
L_F= [F, t];

