function List = list(U_hat)

global PCparams;

List= unique(U_hat,'rows');
