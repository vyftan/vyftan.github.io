function U_hat= ldecode(y_hat, p)

global PCparams;
A= [ ]; U_hat=[];
for i= 0:length(y_hat)
    y1=y_hat(1:i);
    y3= y_hat(i+1:length(y_hat));
    R=[2,3];
    r1= randi([1,2],1);
    y2= R(r1);
    a_i= cat(2,y1,y2,y3);
    A= [A; a_i];
    U_i=pdecode(a_i,'BEC',p);
    U_hat= [U_hat; transpose(U_i)];
end

end
    




