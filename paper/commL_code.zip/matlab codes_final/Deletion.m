function y_hat= Deletion(y)

global PCparams;
r=randi([1,length(y)],1);
z=y;
z(r)=[];
y_hat= z;
end