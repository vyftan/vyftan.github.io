function Final_list = final(List, Poly)

global PCparams;
detect = comm.CRCDetector(Poly, 'ChecksumsPerFrame',1);
A= [ ];
for i = 1 : size(List,1)
    [~, err] = step(detect, transpose(List(i,:)));
    %err = [~, err]
    if (err == 0)
        A = [A; List(i,:)]; 
    end
end
Final_list = A;
        