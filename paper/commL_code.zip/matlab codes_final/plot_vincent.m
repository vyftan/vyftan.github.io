close all; clear; clc;

X = 6:11;  % Values of n varies from n=6 to 11 so that N = 2^6 to 2^11

Y1 = [.652  .459   .146   .028     .003    .001];      %       R = 0.55
Z1 = [.275  .174   .095   .021     .003    .001];


Y2 = [.761   .624   .44     .337     .174    .048];  %       R = 0.6
Z2 = [.487   .43    .407    .329     .174    .048 ];


Y3 = [.537  .382    .061  .006  0 0];      %       R = 0.5
Z3 = [.105  .035    .012  .001  0 0];


figure('Position',[0 0 500 325]);
set(gcf,'PaperPositionMode','auto');

plot(X, Y3, 'g-', X, Z3, 'g--', 'Linewidth', 1.5); hold on;
plot(X, Y1, 'bx-', X, Z1, 'bx--', 'Linewidth', 1.5,  'MarkerSize',8); hold on;
plot(X, Y2, 'ro-', X, Z2, 'ro--', 'Linewidth', 1.5, 'MarkerSize',8); hold on;

h= legend('$R = 0.50, |\mathcal{L}|=1$', '$R = 0.50, |\mathcal{L}|\geq 1$',...
'$R = 0.55, |\mathcal{L}|=1$', '$R = 0.55, |\mathcal{L}|\geq 1$',...
'$R = 0.60, |\mathcal{L}|=1$', '$R = 0.60, |\mathcal{L}|\geq 1$');
set(h,'Interpreter','latex'); 

xlabel('$n = \log_2 N$','Interpreter','latex'); 
ylabel('Overall Error Probabilities','Interpreter','latex'); 
title('Plot of Error Probabilities against Log of Block Length','Interpreter','latex');
grid; 

set(gcf,'color','w');
export_fig(gcf,'FontMode','fixed','FontSize',10,'Color','Transparent','figs/plot_1205.pdf'); 

figure('Position',[0 0 500 325]);
set(gcf,'PaperPositionMode','auto');

semilogy(X, Y2, 'ro-', X, Z2, 'ro--', 'Linewidth', 1.5, 'MarkerSize',8); hold on;
semilogy(X, Y1, 'bx-', X, Z1, 'bx--', 'Linewidth', 1.5,  'MarkerSize',8); hold on;
semilogy(X, Y3, 'g^-', X, Z3, 'g^--', 'Linewidth', 1.5); hold on;

h= legend('$R = 0.60, |\mathcal{L}|=1$', '$R = 0.60, |\mathcal{L}|\geq 1$',...
'$R = 0.55, |\mathcal{L}|=1$', '$R = 0.55, |\mathcal{L}|\geq 1$',...
'$R = 0.50, |\mathcal{L}|=1$', '$R = 0.50, |\mathcal{L}|\geq 1$', 'Location', 'Southwest');
set(h,'Interpreter','latex'); 
%LEG = findobj(h,'type','text');
%et(LEG,'FontSize',8)


xlabel('$n = \log_2 N$','Interpreter','latex'); 
ylabel('Overall Error Probabilities','Interpreter','latex'); 
title('Plot of Error Probabilities against Log of Block Length','Interpreter','latex');
grid; 

ylim([10^-3.5 10^0]);

set(gcf,'color','w');
export_fig(gcf,'FontMode','fixed','FontSize',10,'Color','Transparent','figs/log_plot_1205.pdf'); 
