function Prob= errorprobability_final(n,p, c,b, Poly)

global PCparams;
Count= 0;
True=0;
Part=0;
J= [1 1];
M= 1;
for i= 1: 1000
    L_F=listdecodingfinal(n,p,c,b,Poly);
    if logical(isequal(L_F,J)==1)
        True= True+1;
        Part=Part+1;  
    elseif logical(isequal(L_F(1,2),M)==1)
        Part=Part+1;
    end
    Count= Count+1;
    end
Prob= [1-True/Count, 1-Part/Count];

        