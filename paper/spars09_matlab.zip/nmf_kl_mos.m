function [W, H, store] = nmf_kl_mos(V,n_iter,prior,method,varargin)

% NMF minimizing KL distance through multiplicative updates
% with specified priors and different methods for model order selection

% prior can be either 'G' (Gamma/Exponential), 'HN' (Half Normal) or 'mixed' (Mixed HN on H and G on W)
% method can be either 1 (only H is dependent on beta) or 2 (W and H are dependent on beta)
%
% [W, H, store] = nmf_kl_mos(V, n_iter, prior, method, init_W, init_H, switch_W, switch_H, b)
%
% Input:
%   - V: positive matrix data (F x N)
%   - n_iter: number of iterations
%   - init_W: basis (F x K)
%   - init_H: gains (K x N)
%   - switch_W, switch_H: switches (0 or 1)
%   - b: scale param in beta prior
%
% Alternatively,
% [W, H, cost] = nmf_kl_mos(V, n_iter, prior, method, K)
% uses random initializations.
%
% Outputs : TO UPDATE
%   - W and H such that
%
%               V \approx W * H
%
%   - dist : Kullback-Leibler distance though iterations


[F,N] = size(V);

if nargin == 9
    W = varargin{1};
    H = varargin{2};
    switch_W = varargin{3};
    switch_H = varargin{4};
    b0 = varargin{5};
    K = size(W,2);
elseif nargin == 4
    K = varargin{1};
    W = abs(randn(F,K)) + ones(F,K);
    H = abs(randn(K,N)) + ones(K,N);
    switch_W = 1;
    switch_H = 1;
end

switch_beta = 1;
a = 5*ones(K,1); b = b0*ones(K,1);

% Definitions
store.cost       = zeros(1,n_iter);
store.cost_map   = zeros(1,n_iter);
store.invbeta    = zeros(K,n_iter);

% Initializations
invbeta            = ones(K,1);
V_ap               = W*H;

if strcmp(prior,'HN') && method == 1;
    a_post = N/2 + a -1;
    b_post = sum(H.^2,2)/2 + b;
elseif strcmp(prior,'HN') && method == 2;
    a_post = N/2 + F/2 + a - 1;
    b_post = sum(H.^2,2)/2 + sum(W.^2,1)'/2 + b;
elseif strcmp(prior,'G') && method == 1;
    a_post = N + a - 1;
    b_post = sum(H,2) + b;
elseif strcmp(prior,'G') && method == 2;
    a_post = N + F + a - 1;
    b_post = sum(H,2) + sum(W,1)' + b;
elseif strcmp(prior,'mixed') && method == 2;
    a_post = N/2 + F + a - 1;
    b_post = sum(H.^2,2)/2 + sum(W,1)' + b;
else
    error('no such prior');
end

cost = sum(sum(V.*log(V./V_ap)-V+V_ap));
store.cost(1) = cost;
if method == 1
    store.cost_map(1) = cost + sum(b_post./invbeta) + sum(a_post.*log(invbeta)) +  0.5 * sum(W(:).^2);
elseif method == 2
    store.cost_map(1) = cost + sum(b_post./invbeta) + sum(a_post.*log(invbeta));
else
    error('no such method');
end

store.invbeta(:,1)  = invbeta;

epsilon = sqrt(eps);

%h = waitbar(0,'Please wait...');

%start_time = clock;

for iter = 2:n_iter

    %waitbar(iter/1000,h);

    if switch_H
        if strcmp(prior,'HN') || strcmp(prior,'mixed')
            H = H ./ (W' * ones(F,N) + H./repmat(invbeta ,1,N) + epsilon  ) .* (W' *  (V ./ (W*H)));
        elseif strcmp(prior,'G')
            H = H ./ (W' * ones(F,N) + 1./repmat(invbeta ,1,N) + epsilon  ) .* (W' *  (V ./ (W*H)));
        else
            error('no such method');
        end
    end

    if switch_beta
        if strcmp(prior,'HN') && method == 1;
            b_post = sum(H.^2,2)/2 + b;
        elseif strcmp(prior,'HN') && method == 2;
            b_post = sum(H.^2,2)/2 + sum(W.^2,1)'/2 + b;
        elseif strcmp(prior,'G') && method == 1;
            b_post = sum(H,2) + b;
        elseif strcmp(prior,'G') && method == 2;
            b_post = sum(H,2) + sum(W,1)' + b;
        elseif strcmp(prior,'mixed') && method == 2;
            b_post = sum(H.^2,2)/2 + sum(W,1)' + b;
        else
            error('no such prior');
        end
        invbeta = b_post./a_post;
    end

    if switch_W
        if strcmp(prior,'HN') && method == 1;
            W = W ./ (ones(F,N) * H' + W + epsilon) .* ( (V./(W*H)) * H');
        elseif strcmp(prior,'HN') && method == 2;
            W = W ./ (ones(F,N) * H' + W./repmat(invbeta',F,1) + epsilon) .* ( (V./(W*H)) * H');
        elseif strcmp(prior,'G') && method == 1;
            W = W ./ (ones(F,N) * H' + ones(size(W)) + epsilon) .* ( (V./(W*H)) * H');
        elseif strcmp(prior,'G') && method == 2 || strcmp(prior,'mixed') && method == 2;
            W = W ./ (ones(F,N) * H' + 1./repmat(invbeta',F,1) + epsilon) .* ( (V./(W*H)) * H');
        else
            error('no such prior');
        end
    end

    V_ap = W*H;
    cost = sum(sum(V.*log(V./V_ap)-V+V_ap));

    % Fix scales %%%
    %     if (switch_W && switch_H && 0)
    %         for k = 1:K
    %             scale = sqrt(F / N * sum(H(k,:)) / sum(W(:,k)));
    %             W(:,k) = W(:,k) * scale;
    %             H(k,:) = H(k,:) / scale;
    %         end
    %     end

    store.cost(iter) = cost;

    if method == 1
        store.cost_map(iter) = cost + sum(b_post./invbeta) + sum(a_post.*log(invbeta)) +  0.5 * sum(W(:).^2);
    elseif method == 2
        store.cost_map(iter) = cost + sum(b_post./invbeta) + sum(a_post.*log(invbeta));
    else
        error('no such method');
    end

    store.invbeta(:,iter)  = invbeta;


    if(mod(iter,1e3) == 0)
        disp(['Number of iterations completed = ' num2str(iter)]);
        % disp(['Elapsed time = ' num2str(etime(clock, start_time)) ' seconds.']);
    end

end