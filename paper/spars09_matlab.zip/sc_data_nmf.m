F = 100;
N = 1000;

K_true = 2;

K = 10; 

beta = .1*ones(1,K_true);

sigma = 1;

W_true = repmat(1./sqrt(beta), F,1) .*abs(randn(F,K_true));
W_true = [W_true abs(sigma*randn(F,K-K_true))];
H_true_posneg = repmat(1./sqrt(beta'), 1, N) .* randn(K_true, N);
H_true = abs(H_true_posneg);
H_true = [H_true; abs(sigma*randn(K-K_true,N))];

W_ini = abs(randn(F,K)) + ones(F,K);
H_ini = abs(randn(K,N)) + ones(K,N);

V = W_true*H_true;

[W, H, store] = nmf_kl_mos(V, 5000, 'HN', 2, W_ini, H_ini, 1,1, 2);


