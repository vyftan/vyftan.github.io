function Objectfun = D2object(X,r2,p0,p1)
%The object function of the modified problem D2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Pxyu=[0.5*(1-p0)*(1-p1),0.5*(1-p0)*p1,0.5*p0*(1-p1),0.5*p0*p1;0.5*p0*p1,0.5*p0*(1-p1),0.5*(1-p0)*p1,0.5*(1-p0)*(1-p1)];
%%%%%%%%%%%%%%%%%%%%%%%%%
K0yu=0.5*[X(1) 1-X(1) 1-X(1) X(1)];
K0x_yu=[X(2) X(3) 1-X(3) 1-X(2)];
Qu_y=[X(4) 1-X(4)];
%%%%%%%%%%%%%%%%%%%%%%%%%
K0y=[K0yu(1)+K0yu(3),K0yu(2)+K0yu(4)];
Qyu=[Qu_y(1)*K0y(1),Qu_y(2)*K0y(2),(1-Qu_y(1))*K0y(1),(1-Qu_y(2))*K0y(2)];
K0xyu= [K0x_yu;1-K0x_yu].*(ones(2,1)*K0yu);
%%%%%%%%%%%%%%%%%%%%
KLD=sum(sum(K0xyu.*log(K0xyu./Pxyu)));%D(K0xyu||Pxyu)
Dgamma=log(2)+sum(sum(Qyu.*log([Qu_y,1-Qu_y])))-r2;%gamma
Objectfun=KLD+Dgamma;
end

