function Objectfun = D4object(X,p0,p1)
%The object function of the problem D4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Pxyu=[0.5*(1-p0)*(1-p1),0.5*(1-p0)*p1,0.5*p0*(1-p1),0.5*p0*p1;0.5*p0*p1,0.5*p0*(1-p1),0.5*(1-p0)*p1,0.5*(1-p0)*(1-p1)];
%%%%%%%%%%%%%%%%%%%%%%%%
K0yu=0.5*[X(1) 1-X(1) 1-X(1) X(1)];
K0x_yu=[X(2) X(3) 1-X(3) 1-X(2)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K0xyu= [K0x_yu;1-K0x_yu].*(ones(2,1)*K0yu);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Objectfun=sum(sum(K0xyu.*log(K0xyu./Pxyu)));%D(K0xyu||Pxyu)
end

