function [DoptX,DFVAL] = ExponentD(r1,r2,p0,p1,T)
%The exponent D
%%%%%%%%%%
Pxyu=[0.5*(1-p0)*(1-p1),0.5*(1-p0)*p1,0.5*p0*(1-p1),0.5*p0*p1;0.5*p0*p1,0.5*p0*(1-p1),0.5*(1-p0)*p1,0.5*(1-p0)*(1-p1)];
Pyu=sum(Pxyu,1);
X0=[Pyu(1)*2,Pxyu(1,[1 2])./Pyu([1 2]),Pyu(1)*2,Pxyu(1,[1 2])./Pyu([1 2])].';
%%%%%%%%%%%%%%%%%%%%%
nonConsD5=@(X) deal(D5cons(X,p1,T),[]);
nonConsD2=@(X) deal(D2cons(X,r1,p0,p1,T),[]);
nonConsD4=@(X) deal(D4cons(X,r1,r2,p0,p1,T),[]);
LU=zeros(1,6);
RU=ones(1,6);
options = optimoptions('fmincon','Algorithm','sqp','MaxFunEvals',10000,'display','off');
%%%%%%%%%%%%%%%%%%%%%%
TFVAL=zeros(1,3);
ToptX=zeros(6,3);
[ToptX(:,1),TFVAL(1)] = fmincon(@(X)D5object(X,r1,r2,p0,p1),X0,[],[],[],[],LU,RU,nonConsD5,options);
[ToptX(:,2),TFVAL(2)] = fmincon(@(X)D2object(X,r2,p0,p1),X0,[],[],[],[],LU,RU,nonConsD2,options);
[ToptX(:,3),TFVAL(3)] = fmincon(@(X)D4object(X,p0,p1),X0,[],[],[],[],LU,RU,nonConsD4,options);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ActiveFlagD2 = D2ActiveFlag(ToptX(:,2),r2);
ActiveFlagD5 =D5ActiveFlag(ToptX(:,1),r1,r2,p0);
if ActiveFlagD5  && ActiveFlagD2
    DactiveFlag=[1,2,3];
elseif ActiveFlagD5 
    DactiveFlag=[1,3];
elseif ActiveFlagD2
    DactiveFlag=[2,3];
else
    DactiveFlag=3;
end
[DFVAL,temp1]=min(TFVAL(DactiveFlag));
DoptX=ToptX(:,DactiveFlag(temp1));
end
