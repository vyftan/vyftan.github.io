function Cons = K4cons(X,r1,r2,p0,p1,T)
%The constraint of the problem K4
%%%%%%%%%%%%%%%%%%%%%%%%%%
W=[1-p1,p1;p1,1-p1];
Px_u=[1-p0,p0;p0,1-p0];
%%%%%%%%%%%%%%%%%%%
K0yu=0.5*[X(1) 1-X(1) 1-X(1) X(1)];
Qu_y=[X(4) 1-X(4)];
K1x_yu=[X(5),X(6),1-X(6),1-X(5);1-X(5),1-X(6),X(6),X(5)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K0y=[K0yu(1)+K0yu(3),K0yu(2)+K0yu(4)];
Qyu=[Qu_y(1)*K0y(1),Qu_y(2)*K0y(2),(1-Qu_y(1))*K0y(1),(1-Qu_y(2))*K0y(2)];
K1xyu= K1x_yu.*(ones(2,1)*Qyu);
K1xu=[K1xyu(:,1)+K1xyu(:,2),K1xyu(:,3)+K1xyu(:,4)];
K1xy=[K1xyu(:,1)+K1xyu(:,3),K1xyu(:,2)+K1xyu(:,4)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Kgamma=log(2)+sum(sum(Qyu.*log([Qu_y,1-Qu_y])))-r2;%gamma
Kbeta=sum(sum(K1xu.*log(1./Px_u)))-sum(sum(K1xyu.*log(1./K1x_yu)))-r1;%beta
KS0 = S0(X(1),r1,p0,p1);
KOmega=sum(sum(K1xy.*log(1./W)))-KS0-T;%Omega:the left side of the contradiction in L3
Cons=[Kgamma,Kgamma+Kbeta,KOmega+Kgamma+Kbeta];
end

