function S0 = S0(k11,r1,p0,p1)
%The value of S0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Pxyu=[0.5*(1-p0)*(1-p1),0.5*(1-p0)*p1,0.5*p0*(1-p1),0.5*p0*p1;0.5*p0*p1,0.5*p0*(1-p1),0.5*(1-p0)*p1,0.5*(1-p0)*(1-p1)];
Pyu=sum(Pxyu,1);
X0=Pxyu(1,[1 2])./Pyu([1 2]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nonCons=@(X) deal(S0cons(X,k11,p0,r1 ),[]);
LU=zeros(1,2);
RU=ones(1,2);
options = optimoptions('fmincon','Algorithm','sqp','MaxFunEvals',10000,'display','off');
[~,S0 ] = fmincon(@(X)S0object(X,k11,r1,p0,p1),X0,[],[],[],[],LU,RU,nonCons,options);
end

