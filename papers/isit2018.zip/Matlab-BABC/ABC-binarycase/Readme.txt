Run 'binarycase.m' to get the data.
Run ABCplot to plot the figures in the paper from the data file 'TestDate_N1000.mat'.