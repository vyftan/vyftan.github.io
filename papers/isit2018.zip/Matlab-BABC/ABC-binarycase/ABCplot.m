%Plot these figures in the paper. May need the R2017 version due to 'MarkerIndices' in the code. 
%You can remove the code correlated to 'MarkerIndices', and only use the color to distinguish the different lines.

clc
clear
close All
load NTestdata_N1000.mat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Due to the calculation error from Matlab, the value of "0" may be a
%negative number with a very small value (about 10^-17). You can remove this operation. 
%%%%%%%%%%%%%%%%%%%%%%%%
ExpM1=max(ExpM1,0);
ExpM2=max(ExpM2,0);
%%%%%%%%%%%%%%%%%%%%%%


figure(1)
grid on
hold on
plot(c1vecR2(1,:),ExpM1(1,:).','g->','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c1vecR2(1,:),ExpM2(1,:).','b-s','LineWidth',2,'MarkerIndices',25:50:1000);
plot(c1vecR2(2,:),ExpM1(2,:).','m-*','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c1vecR2(2,:),ExpM2(2,:).','k-+','LineWidth',2,'MarkerIndices',1:50:1000);
c1XTick=sort([0:0.05:0.2,yr1_max+yr2_max-0.02,yr2_max]).';
set(gca,'XTick',c1XTick,'XTickLabel',num2str(c1XTick,'%.2f'))
ylabel('Error Exponent','FontSize',15)
xlabel({'$R_2$ [nats/channel use]'},'Interpreter','latex','FontSize',15)
plot([yr1_max+yr2_max-0.02,yr2_max],zeros(1,2),'p','LineWidth',2,'MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',10);
legend({'$E_1^{\mathrm{t}}$ for $R_1=0.02$','$E_2^{\mathrm{t}}$ for $R_1=0.02$','$E_1^{\mathrm{t}}$ for $R_1=0.08$','$E_2^{\mathrm{t}}$ for $R_1=0.08$','Capacity point'},'Interpreter','latex','FontSize',15)


figure(2)
grid on
hold on
plot(c2vecR1(1,:),ExpM1(3,:).','g->','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c2vecR1(1,:),ExpM2(3,:).','b-s','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c2vecR1(2,:),ExpM1(4,:).','m-*','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c2vecR1(2,:),ExpM2(4,:).','k-+','LineWidth',2,'MarkerIndices',25:50:1000);
c2XTick=sort([0,0.02,0.1,0.12,yr1_max+yr2_max-0.15,yr1_max]).';
set(gca,'XTick',c2XTick,'XTickLabel',num2str(c2XTick,'%.2f'))
ylabel('Error Exponent','FontSize',15)
xlabel({'$R_1$ [nats/channel use]'},'Interpreter','latex','FontSize',15)
plot([yr1_max+yr2_max-0.15,yr1_max],zeros(1,2),'p','LineWidth',2,'MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',10);
legend({'$E_1^{\mathrm{t}}$ for $R_2=0.05$','$E_2^{\mathrm{t}}$ for $R_2=0.05$','$E_1^{\mathrm{t}}$ for $R_2=0.15$','$E_2^{\mathrm{t}}$ for $R_2=0.15$','Capacity point'},'Interpreter','latex','FontSize',15)





figure(3)
grid on
hold on
plot(c3vecT(1,:),ExpM1(5,:).','g->','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c3vecT(1,:),(ExpM1(5,:)+c3vecT(1,:)).','b-s','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c3vecT(1,:),ExpM1(6,:).','m-*','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c3vecT(1,:),(ExpM1(6,:)+c3vecT(1,:)).','k-+','LineWidth',2,'MarkerIndices',1:50:1000);
c3XTick=(0:0.02:0.1).';
set(gca,'XTick',c3XTick,'XTickLabel',num2str(c3XTick,'%.2f'))
ylabel('Error Exponent','FontSize',15)
xlabel({'$T$ [nats/channel use]'},'Interpreter','latex','FontSize',15)
legend({'$E_1^{\mathrm{t}}$ for $(R_1,R_2)=(0.01,0.01)$','$E_1^{\mathrm{u}}$ for $(R_1,R_2)=(0.01,0.01)$','$E_1^{\mathrm{t}}$ for $(R_1,R_2)=(0.02,0.05)$','$E_1^{\mathrm{u}}$ for $(R_1,R_2)=(0.02,0.05)$'},'Interpreter','latex','FontSize',15,'Location','NorthWest')


figure(4)
grid on
hold on
plot(c4vecT(1,:),ExpM2(7,:).','g->','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c4vecT(1,:),(ExpM2(7,:)+c4vecT(1,:)).','b-s','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c4vecT(1,:),ExpM2(8,:).','m-*','LineWidth',2,'MarkerIndices',1:50:1000);
plot(c4vecT(1,:),(ExpM2(8,:)+c4vecT(1,:)).','k-+','LineWidth',2,'MarkerIndices',1:50:1000);
c4XTick=(0:0.05:0.2).';
set(gca,'XTick',c4XTick,'XTickLabel',num2str(c4XTick,'%.2f'))
ylabel('Error Exponent','FontSize',15)
xlabel({'$T$ [nats/channel use]'},'Interpreter','latex','FontSize',15)
legend({'$E_2^{\mathrm{t}}$ for $(R_1,R_2)=(0.01,0.01)$','$E_2^{\mathrm{u}}$ for $(R_1,R_2)=(0.01,0.01)$','$E_2^{\mathrm{t}}$ for $(R_1,R_2)=(0.02,0.05)$','$E_2^{\mathrm{u}}$ for $(R_1,R_2)=(0.02,0.05)$'},'Interpreter','latex','FontSize',15,'Location','NorthWest')


