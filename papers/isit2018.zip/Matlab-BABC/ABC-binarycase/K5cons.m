function Cons = K5cons(X,r1,p0,p1,T)
%The constraint of the problem K5
%%%%%%%%%%%%%%%%%%%%%%%%%%
W=[1-p1,p1;p1,1-p1];
%%%%%%%%%%%%%%%%%%%%
K0yu=0.5*[X(1) 1-X(1) 1-X(1) X(1)];
Qu_y=[X(4) 1-X(4)];
K1x_yu=[X(5),X(6),1-X(6),1-X(5);1-X(5),1-X(6),X(6),X(5)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%
K0y=[K0yu(1)+K0yu(3),K0yu(2)+K0yu(4)];
Qyu=[Qu_y(1)*K0y(1),Qu_y(2)*K0y(2),(1-Qu_y(1))*K0y(1),(1-Qu_y(2))*K0y(2)];
K1xyu= K1x_yu.*(ones(2,1)*Qyu);
K1xy=[K1xyu(:,1)+K1xyu(:,3),K1xyu(:,2)+K1xyu(:,4)];
%%%%%%%%%%%%%%%%%%%%%%%%%
KS0 = S0(X(1),r1,p0,p1);
Cons=sum(sum(K1xy.*log(1./W)))-KS0-T;%Omega:the left side of the contradiction in L3
end

