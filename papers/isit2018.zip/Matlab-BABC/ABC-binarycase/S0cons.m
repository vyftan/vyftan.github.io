function Cons = S0cons(X,k11,p0,r1)
%The constraint of the problem S0
%%%%%%%%%%%%%%%%%%%%%%%%%%
Px_u=[1-p0,p0;p0,1-p0];
%%%%%%%%%%%%%%%%%%%
K0yu=0.5*[k11 1-k11 1-k11 k11];
H1x_yu=[X(1),X(2),1-X(2),1-X(1);1-X(1),1-X(2),X(2),X(1)];
H1xyu= H1x_yu.*(ones(2,1)*K0yu);
H1xu=[H1xyu(:,1)+H1xyu(:,2),H1xyu(:,3)+H1xyu(:,4)];
%%%%%%%%%%%%%%%%%%%%%%%%%
Cons=sum(sum(H1xu.*log(1./Px_u)))-sum(sum(H1xyu.*log(1./H1x_yu)))-r1;%beta
end

