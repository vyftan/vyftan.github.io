function ActiveFlag = G1ActiveFlag(X,p0,r1)
%Indicate whether the optimal solution of the modified problem G1 is active for the problem G.
%"1" means active
%%%%%%%%%%%%%%%%%%%%%%
Px_u=[1-p0,p0;p0,1-p0];
%%%%%%%%%%%%%%%%%%%%%%
K0yu=0.5*[X(1), 1-X(1), 1-X(1), X(1)];
K1x_yu=[X(4),X(5),1-X(5),1-X(4);1-X(4),1-X(5),X(5),X(4)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K1xyu= K1x_yu.*(ones(2,1)*K0yu);
K1xu=[K1xyu(:,1)+K1xyu(:,2),K1xyu(:,3)+K1xyu(:,4)];
%%%%%%%%%%%%%%%%%%%%%%%%%
Gbeta=sum(sum(K1xu.*log(1./Px_u)))-sum(sum(K1xyu.*log(1./K1x_yu)))-r1;%beta
%%%%%%%%%%%%%%%%%%%%%%%%%
ActiveFlag= Gbeta >= 0;
end

