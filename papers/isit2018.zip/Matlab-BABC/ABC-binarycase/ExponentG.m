function [GoptX,GFVAL] = ExponentG(r1,p0,p1,T)
%The exponent G
%%%%%%%%%%
Pxyu=[0.5*(1-p0)*(1-p1),0.5*(1-p0)*p1,0.5*p0*(1-p1),0.5*p0*p1;0.5*p0*p1,0.5*p0*(1-p1),0.5*(1-p0)*p1,0.5*(1-p0)*(1-p1)];
Pyu=sum(Pxyu,1);
X0=[Pyu(1)*2,Pxyu(1,[1 2])./Pyu([1 2]),Pxyu(1,[1 2])./Pyu([1 2])].';
%%%%%%%%%%%%%%%%%%%%%
nonConsG1=@(X) deal(G1cons(X,p1,T),[]);
nonConsG2=@(X) deal(G2cons(X,r1,p0,p1,T),[]);
LU=zeros(1,5);
RU=ones(1,5);
options = optimoptions('fmincon','Algorithm','sqp','MaxFunEvals',10000,'display','off');
%%%%%%%%%%%%%%%%%%%%%%
TFVAL=zeros(1,2);
ToptX=zeros(5,2);
[ToptX(:,1),TFVAL(1)] = fmincon(@(X)G1object(X,r1,p0,p1),X0,[],[],[],[],LU,RU,nonConsG1,options);
[ToptX(:,2),TFVAL(2)] = fmincon(@(X)G2object(X,p0,p1),X0,[],[],[],[],LU,RU,nonConsG2,options);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if G1ActiveFlag(ToptX(:,1),p0,r1)
    [GFVAL,temp]=min(TFVAL);
    GoptX=ToptX(:,temp);
else
    GFVAL=TFVAL(2);
    GoptX=ToptX(:,2);
end
end
