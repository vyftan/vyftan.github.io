function ActiveFlag = D2ActiveFlag(X,r2)
%Indicate whether the optimal solution of the modified problem D2 is active for the problem D.
%"1" means active
%%%%%%%%%%%%%%%%%%%%%%
K0yu=0.5*[X(1) 1-X(1) 1-X(1) X(1)];
Qu_y=[X(4) 1-X(4)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K0y=[K0yu(1)+K0yu(3),K0yu(2)+K0yu(4)];
Qyu=[Qu_y(1)*K0y(1),Qu_y(2)*K0y(2),(1-Qu_y(1))*K0y(1),(1-Qu_y(2))*K0y(2)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Dgamma=log(2)+sum(sum(Qyu.*log([Qu_y,1-Qu_y])))-r2;%gamma
%%%%%%%%%%%%%%%%%%%%
ActiveFlag= Dgamma>=0;
end

