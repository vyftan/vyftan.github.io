function [KoptX,KFVAL] = ExponentK(r1,r2,p0,p1,T)
%The exponent K
%%%%%%%%%%
Pxyu=[0.5*(1-p0)*(1-p1),0.5*(1-p0)*p1,0.5*p0*(1-p1),0.5*p0*p1;0.5*p0*p1,0.5*p0*(1-p1),0.5*(1-p0)*p1,0.5*(1-p0)*(1-p1)];
Pyu=sum(Pxyu,1);
X0=[Pyu(1)*2,Pxyu(1,[1 2])./Pyu([1 2]),Pyu(1)*2,Pxyu(1,[1 2])./Pyu([1 2])].';
%%%%%%%%%%%%%%%%%%%%%
nonConsK5=@(X) deal(K5cons(X,r1,p0,p1,T),[]);
nonConsK2=@(X) deal(K2cons(X,r1,p0,p1,T),[]);
nonConsK4=@(X) deal(K4cons(X,r1,r2,p0,p1,T),[]);
LU=zeros(1,6);
RU=ones(1,6);
options = optimoptions('fmincon','Algorithm','sqp','MaxFunEvals',10000,'display','off');
%options = optimoptions('fmincon','Algorithm','sqp','MaxFunEvals',10000);
%%%%%%%%%%%%%%%%%%%%%%
TFVAL=zeros(1,3);
ToptX=zeros(6,3);
[ToptX(:,1),TFVAL(1)] = fmincon(@(X)D5object(X,r1,r2,p0,p1),X0,[],[],[],[],LU,RU,nonConsK5,options);
[ToptX(:,2),TFVAL(2)] = fmincon(@(X)D2object(X,r2,p0,p1),X0,[],[],[],[],LU,RU,nonConsK2,options);
[ToptX(:,3),TFVAL(3)] = fmincon(@(X)D4object(X,p0,p1),X0,[],[],[],[],LU,RU,nonConsK4,options);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ActiveFlagD2 = D2ActiveFlag(ToptX(:,2),r2);
ActiveFlagD5 =D5ActiveFlag(ToptX(:,1),r1,r2,p0);
if ActiveFlagD5  && ActiveFlagD2
    DactiveFlag=[1,2,3];
elseif ActiveFlagD5 
    DactiveFlag=[1,3];
elseif ActiveFlagD2
    DactiveFlag=[2,3];
else
    DactiveFlag=3;
end
[KFVAL,temp1]=min(TFVAL(DactiveFlag));
KoptX=ToptX(:,DactiveFlag(temp1));
end
