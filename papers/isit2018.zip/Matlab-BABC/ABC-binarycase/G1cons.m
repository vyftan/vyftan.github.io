function Cons = G1cons(X,p1,T)
%The constraint of the modified problem G1
%%%%%%%%%%%%%%%%%%%%%%%%%%
W=[1-p1,p1;p1,1-p1];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K0yu=0.5*[X(1), 1-X(1), 1-X(1), X(1)];
K0x_yu=[X(2), X(3),1-X(3),1-X(2)];
K1x_yu=[X(4),X(5),1-X(5),1-X(4);1-X(4),1-X(5),X(5),X(4)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K1xyu= K1x_yu.*(ones(2,1)*K0yu);
K1xy=[K1xyu(:,1)+K1xyu(:,3),K1xyu(:,2)+K1xyu(:,4)];
K0xyu= [K0x_yu;1-K0x_yu].*(ones(2,1)*K0yu);
K0xy=[K0xyu(:,1)+K0xyu(:,3),K0xyu(:,2)+K0xyu(:,4)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Cons=sum(sum(K1xy.*log(1./W)))+sum(sum(K0xy.*log(W)))-T;%Omega:the left side of the contradiction in L2
end

