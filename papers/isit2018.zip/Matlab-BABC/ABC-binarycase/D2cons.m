function Cons = D2cons(X,r1,p0,p1,T)
%The constraint of the modified problem D2
%%%%%%%%%%%%%%%%%%%%%%%%%%
W=[1-p1,p1;p1,1-p1];
Px_u=[1-p0,p0;p0,1-p0];
%%%%%%%%%%%%%%%%%%%%%%%%%%
K0yu=0.5*[X(1) 1-X(1) 1-X(1) X(1)];
K0x_yu=[X(2) X(3) 1-X(3) 1-X(2)];
Qu_y=[X(4) 1-X(4)];
K1x_yu=[X(5),X(6),1-X(6),1-X(5);1-X(5),1-X(6),X(6),X(5)];
%%%%%%%%%%%%%%%%
K0y=[K0yu(1)+K0yu(3),K0yu(2)+K0yu(4)];
Qyu=[Qu_y(1)*K0y(1),Qu_y(2)*K0y(2),(1-Qu_y(1))*K0y(1),(1-Qu_y(2))*K0y(2)];
K1xyu= K1x_yu.*(ones(2,1)*Qyu);
K1xu=[K1xyu(:,1)+K1xyu(:,2),K1xyu(:,3)+K1xyu(:,4)];
K1xy=[K1xyu(:,1)+K1xyu(:,3),K1xyu(:,2)+K1xyu(:,4)];
K0xyu= [K0x_yu;1-K0x_yu].*(ones(2,1)*K0yu);
K0xy=[K0xyu(:,1)+K0xyu(:,3),K0xyu(:,2)+K0xyu(:,4)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Dbeta=sum(sum(K1xu.*log(1./Px_u)))-sum(sum(K1xyu.*log(1./K1x_yu)))-r1;%beta
DOmega=sum(sum(K1xy.*log(1./W)))+sum(sum(K0xy.*log(W)))-T;%Omega:the left side of the contradiction in L1
Cons =[Dbeta;DOmega+Dbeta];
end

