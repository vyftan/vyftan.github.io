function Objectfun = S0object(X,k11,r1,p0,p1)
%The object function of the modified problem S0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Px_u=[1-p0,p0;p0,1-p0];
W=[1-p1,p1;p1,1-p1];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K0yu=0.5*[k11 1-k11 1-k11 k11];
H1x_yu=[X(1),X(2),1-X(2),1-X(1);1-X(1),1-X(2),X(2),X(1)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
H1xyu= H1x_yu.*(ones(2,1)*K0yu);
H1xu=[H1xyu(:,1)+H1xyu(:,2),H1xyu(:,3)+H1xyu(:,4)];
H1xy=[H1xyu(:,1)+H1xyu(:,3),H1xyu(:,2)+H1xyu(:,4)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Sbeta=sum(sum(H1xu.*log(1./Px_u)))-sum(sum(H1xyu.*log(1./H1x_yu)))-r1;%beta
Objectfun=sum(sum(H1xy.*log(1./W)))+Sbeta;
end

