%The main file for the example in paper.
clc
clear
close All
p0=0.1;%the crossover probability of UX
p1=0.2;%the crossover probability of XY
tpy=p0*(1-p1)+(1-p0)*p1;
yr1_max=tpy*log(1/(tpy))+(1-tpy)*log(1/(1-tpy))-(p1*log(1/(p1))+(1-p1)*log(1/(1-p1)));%I(X;Y|U)
yr2_max=log(2)-(tpy*log(1/(tpy))+(1-tpy)*log(1/(1-tpy)));%I(U;Y)


CaseN=998; %the accuracy for the argument
%%%%%%%%%% case1 T=0 for R2
c1vecR1=[0.02,0.08].'*ones(1,CaseN+2);
c1vecR2=sort([ones(2,1)*[(0:0.2/(CaseN-1):0.2),yr2_max],(yr1_max+yr2_max-[0.02,0.08].')],2);
c1vecT=ones(2,1)*zeros(1,CaseN+2);

%%%%%%%%%% case2 T=0 for R1
c2vecR1=sort([ones(2,1)*[(0:0.12/(CaseN-1):0.12),yr1_max],[0.12,yr1_max+yr2_max-0.15].'],2);
c2vecR2=[0.05,0.15].'*ones(1,CaseN+2);
c2vecT=ones(2,1)*zeros(1,CaseN+2);

%%%%%%%%%%%%%% case3 for T
c3vecR1=[0.01;0.02]*ones(1,CaseN+2);
c3vecR2=[0.01;0.05]*ones(1,CaseN+2);
c3vecT=ones(2,1)*(0:0.1/(CaseN+1):0.1);

%%%%%%%%%%%%%% case4 for T
c4vecR1=[0.01;0.02]*ones(1,CaseN+2);
c4vecR2=[0.01;0.05]*ones(1,CaseN+2);
c4vecT=ones(2,1)*(0:0.2/(CaseN+1):0.2);

%%%%%%%%%%%%%%%%%%%%%
vecR1=reshape([c1vecR1;c2vecR1;c3vecR1;c4vecR1].',1,8*(CaseN+2));
vecR2=reshape([c1vecR2;c2vecR2;c3vecR2;c4vecR2].',1,8*(CaseN+2));
vecT=reshape([c1vecT;c2vecT;c3vecT;c4vecT].',1,8*(CaseN+2));
Tolsize=size(vecR1);
GFVAL=zeros(Tolsize);
DFVAL=zeros(Tolsize);
KFVAL=zeros(Tolsize);

parfor i=1:Tolsize(2)
[~,GFVAL(i)]=ExponentG(vecR1(i),p0,p1,vecT(i));
[~,DFVAL(i)]=ExponentD(vecR1(i),vecR2(i),p0,p1,vecT(i));
[~,KFVAL(i)]=ExponentK(vecR1(i),vecR2(i),p0,p1,vecT(i));
end

GFVAL=reshape(GFVAL,CaseN+2,8).';
DFVAL=reshape(DFVAL,CaseN+2,8).';
KFVAL=reshape(KFVAL,CaseN+2,8).';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%Due to the calculation error from Matlab, the value of "0" may be a
%negative number with a very small value (about 10^-17). You can add this operation. 
%%%%%%%%%%%%%%%%%%%%%%%%
% GFVAL=max(GFVAL,0);
% DFVAL=max(DFVAL,0);
% KFVAL=max(KFVAL,0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ExpM1=min(cat(3,GFVAL,DFVAL),[],3);
ExpM2=max(cat(3,DFVAL,KFVAL),[],3);
