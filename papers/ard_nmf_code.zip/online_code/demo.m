% Demo file for ARD-NMF
% Just run demo.m in Matlab

%% Load data
load swimmer
[F,N] = size(V);

% Display a few random data samples
figure;
colormap('gray');

for i = 1:6
    subplot(2,3,i);
    n = randi(N);
    imagesc(reshape(V(:,n),32,32));
    axis image
    title(['sample ' num2str(n)])
end

%% Set parameters
beta = 1; % Beta-divergence shape parameter
K = 32; % Nb of components
a = 10; % Relevance parameters shape parameter
tol = 1e-5; % Tolerance value for convergence
n_iter_max = 10000; % Max nb of iterations
L = 1; % L1-ARD (L=1) or L2-ARD (L = 2)

%% Initialize
mean_V = sum(V(:))/(F*N); % Data sample mean per component
W_ini = (rand(F,K) + 1)*(sqrt(mean_V/K));
H_ini = (rand(K,N) + 1)*(sqrt(mean_V/K));

%% Run the algorithm
if L == 1 % L1-ARD
    
    % Set b using method of moments (see paper)
    b = sqrt((a-1)*(a-2)*mean_V/K);
    [W, H, lambdas, obj, fit, bound] = ardnmf_L1(V, beta, tol, n_iter_max, W_ini, H_ini, a, b);
    
elseif L == 2 % L2-ARD
    
    % Set b using method of moments (see paper)
    b = (pi/2)*(a-1)*mean_V/K;
    [W, H, lambdas, obj, fit, bound] = ardnmf_L2(V, beta, tol, n_iter_max, W_ini, H_ini, a, b);
    
end

%% Display fit and relevance parameters
figure;

if sum(obj<=0) == 0
    subplot(411);
    loglog(obj,'k');
    axis tight;
    title('objective function')
end

subplot(412);
loglog(fit,'k');
axis tight;
title('fit to data (beta-divergence)')

subplot(212)
plot(lambdas'-bound,'k')
xlim([1 length(fit)])
title('relevance')

%% Display learnt dictionary

% Sort variables according to relevance
[junk,order] = sort(lambdas(:,end),1,'descend');
W_o = W(:,order);
H_o = H(order,:);
lambda_o = lambdas(order,end);

% Rescale W by prior expectation for improved readability (see paper)
if L == 1
    W_sc = W_o * diag(lambda_o);
elseif L == 2
    W_sc = W_o * diag(sqrt(2*lambda_o/pi));
end

% Rescale values to [1:64] to unify colormaps between plots
W_sc = floor(64*W_sc/max(W_sc(:))+1);

% Display
figure;
colormap('gray');

for k=1:K,
    subplot(4,ceil(K/4),k);
    image(reshape(W_sc(:,k),32,32));
    axis image
    title(['Dictionary element ' num2str(k)])
end