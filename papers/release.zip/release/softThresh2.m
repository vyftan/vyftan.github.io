function R_thr = softThresh2(R,lambda,M)
% Soft thresholding operator. 

[F,N] = size(R);
R_thr = sign(R).*min(max(abs(R)-lambda*ones(F,N),0),M);

end

