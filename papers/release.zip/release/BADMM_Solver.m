function [W,H,R,obj] = BADMM_Solver(V, lambda, rho1, rho2, rho3, W, M, eps, maxItr)
% Batch robust NMF using ADMM. 
% Input:
% V: Data matrix (with outliers).
% lambda: regularization weight
% rho{1,2,3}: penalty paramters
% W: learned W from previous passes
% M: the max. value of entries of r
% eps: the threshold for terminating iterations 
% maxItr: max. number of iterations 
% Output:
% W: learned basis matrix 
% H: learned coefficient matrix 
% R: learned outlier matrix 
% obj: sequence of objective values over iterations

% Copyright: Renbo Zhao (4 Oct 2016)

[F,N] = size(V);
K = size(W,2);

% Initialization 
U = abs(randn(K,N));
A = abs(randn(K,N));
R = abs(randn(F,N));
Q = abs(randn(F,N));
B = abs(randn(F,N));
Psi = abs(randn(F,K));          
D = abs(randn(F,K));          

nItr = 0;
obj = zeros(1,maxItr);

while  nItr <= 2 || (abs((obj(nItr)-obj(nItr-1))/obj(nItr-1)) > eps && nItr < maxItr)
    
    H = (W'*W+rho1*eye(K))\(W'*(V-R)+rho1*U-A);
    R = wthresh(rho2*Q+V-B-W*H,'s',lambda)/(1+rho2);
    W = ((V-R)*H'-D+rho3*Psi)/(H*H'+rho3*eye(K));
    U = max(H + A/rho1,0);          % set negative entries to zero
    Q = max(min(R + B/rho2,M),-M);  % proj. entries in [-M.M]
    Psi = projC(W + D/rho3);
    A = A + rho1*(H-U);
    B = B + rho2*(R-Q);
    D = D + rho3*(W-Psi);
    
    nItr = nItr + 1;
    obj(nItr) = 1/2*norm(V-W*H-R,'fro')^2 + lambda*sum(abs(R(:)));
    
end

end



