function [W,H,R] = OADMM_Solver(V, lambda, mb_size, rho1, rho2, rho3, W, M, maxItr1, maxItr2, eps1, eps2)
% Online robust NMF using ADMM.
% Input:
% V: Data matrix (with outliers).
% lambda: regularization weight
% mb_size: size of mini batch (input data size at one time)
% rho{1,2,3}: penalty paramters
% isVerbose: determine whether to output objectives to command window
% W: learned W from previous passes
% M: the max. value of entries of r
% maxItr1: max. number of iterations for getting h and r
% maxItr2: max. number of iterations for updating W
% eps1: the threshold for terminating iterations in h, r (relative dec. in obj.)
% eps2: the threshold for terminating iterations in W 
% Output:
% W: learned basis matrix 
% H,R: learned coefficient and outlier vectors over time
% N.B.: Both algorithms (find h,r and update W) are terminated by the relative decrease in the objective value. 

% Copyright: Renbo Zhao (4 Oct 2016)

[F,N] = size(V);
K = size(W,2);

% Initialization 
h = rand(K,mb_size);    
u = rand(K,mb_size);
alpha = rand(K,mb_size);
r = rand(F,mb_size);
q = rand(F,mb_size);
beta = rand(F,mb_size);
Q = rand(F,K);          
D = rand(F,K);          

H = zeros(K,N);         % Record the coefficient and outlier vectors over time
R = zeros(F,N);         

A = zeros(K,K);         % Sufficient Statistics
B = zeros(F,K);
n_batch = ceil(N/mb_size);


for i = 1:n_batch
    
    idx1 = (i-1)*mb_size + 1;
    idx2 = min(i*mb_size,N);
    v = V(:,idx1:idx2);
    if i == n_batch               % use part of previous results
        h = h(:,1:size(v,2)); 
        u = u(:,1:size(v,2));
        alpha = alpha(:,1:size(v,2));
        r = r(:,1:size(v,2));
        q = q(:,1:size(v,2));
        beta = beta(:,1:size(v,2));
    end
    [h,u,alpha,r,q,beta] = get_hr(v,W,h,u,alpha,r,q,beta,lambda,maxItr1,eps1,rho1,rho2,M); % warm restart
    H(:,idx1:idx2) = h;     % Store coefficient and outlier vectors
    R(:,idx1:idx2) = r;
    
    A = A + h*h';           % Update Suff. Stats
    B = B + (v-r)*h';
    [W,Q,D] = updateW(W,Q,D,A,B,maxItr2,rho3,eps2); % warm restart
    
end
    
end


function [h,u,alpha,r,q,beta] = get_hr(v,W,h,u,alpha,r,q,beta,lambda,maxItr1,eps1,rho1,rho2,M)
% Get h and r from previous dictionary W_{t-1} and current input data v

nItr = 0;
obj = zeros(1,maxItr1);
K = size(h,1);

while  nItr <= 2 || (abs((obj(nItr)-obj(nItr-1))/obj(nItr-1)) > eps1 && nItr < maxItr1) % short-circuit logic
    h = (W'*W+rho1*eye(K))\(W'*(v-r)+rho1*u-alpha);
    r = wthresh(rho2*q+v-beta-W*h,'s',lambda)/(1+rho2);
    u = max(h + alpha/rho1,0);         % set negative entries to zero
    q = max(min(r + beta/rho2,M),-M);  % proj. entries in [-M,M]
    alpha = alpha + rho1*(h-u);
    beta = beta + rho2*(r-q);
    nItr = nItr + 1;
    obj(nItr) = 1/2*norm(v-W*h-r,'fro')^2+lambda*sum(abs(r(:)));
end

end

function [W,Q,D] = updateW(W,Q,D,A,B,maxItr2,rho3,eps2)
% Update W given suff. stats A, B and C

K = size(W,2);

nItr = 0;
obj = zeros(1,maxItr2);

while nItr <= 2 || (abs((obj(nItr)-obj(nItr-1))/obj(nItr-1)) > eps2 && nItr < maxItr2)
    W = (B-D+rho3*Q)/(A+rho3*eye(K));
    Q = projC(W + D/rho3);
    D = D + rho3*(W-Q);
    nItr = nItr + 1;
    obj(nItr) = 1/2*trace(W'*W*A) - trace(W'*B); 
end

end
