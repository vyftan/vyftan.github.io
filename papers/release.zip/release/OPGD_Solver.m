function [W,H,R] = OPGD_Solver(V, lambda, mb_size, W, M, stepMulp, maxItr1, maxItr2, eps1, eps2)
% Online robust NMF using PGD.
% Input:
% V: Data matrix (with outliers).
% lambda: regularization weight
% mb_size: size of mini batch (input data size at one time)
% rho{1,2,3}: penalty paramters
% isVerbose: determine whether to output objectives to command window
% W: learned W from previous passes
% M: the max. value of entries of r
% maxItr1: max. number of iterations for getting h and r
% maxItr2: max. number of iterations for updating W
% eps1: the threshold for terminating iterations in h, r (relative dec. in obj.)
% eps2: the threshold for terminating iterations in W 
% Output:
% W: learned basis matrix 
% H,R: learned coefficient and outlier vectors over time
% N.B.: Both algorithms (find h,r and update W) are terminated by the relative decrease in the objective value. 

% Copyright: Renbo Zhao (4 Oct 2016)

[F,N] = size(V);
K = size(W,2);

% Initilization
h = rand(K,mb_size);    % Initialize h and r
r = rand(F,mb_size);

H = zeros(K,N);         % Pre-allocation
R = zeros(F,N);         % Used to calculate obj. values

A = zeros(K,K);         % Sufficient Statistics
B = zeros(F,K);
n_batch = ceil(N/mb_size);

for i = 1:n_batch

    idx1 = (i-1)*mb_size + 1;
    idx2 = min(i*mb_size,N);
    v = V(:,idx1:idx2);
    if i == n_batch               % use part of prev. results
        h = h(:,1:size(v,2));
        r = r(:,1:size(v,2));
    end
    [h,r] = get_hr(v,W,h,r,lambda,maxItr1,eps1,M,stepMulp); % warm restart
    H(:,idx1:idx2) = h;     % Store coefficient and outlier vectors
    R(:,idx1:idx2) = r;
    
    A = A + h*h';           % Update Suff. Stats
    B = B + (v-r)*h';
    W = updateW(W,A,B,maxItr2,eps2,stepMulp); % warm restart
    
end

end


function [h,r] = get_hr(v,W,h,r,lambda,maxItr1,eps1,M,stepMulp)
% Get h and r from previous dictionary W_{t-1} and current input data v

nItr = 0;
obj = zeros(1,maxItr1);
L = norm(W,2)^2;             % Lipschitz constant
eta = 1/L*stepMulp;          % stepsize

while  nItr <= 2 || (abs((obj(nItr)-obj(nItr-1))/obj(nItr-1)) > eps1 && nItr < maxItr1)
    h = max(h-eta*W'*(W*h+r-v),0);
    r = softThresh2(v-W*h,lambda,M);
    nItr = nItr + 1;
    obj(nItr) = 1/2*norm(v-W*h-r,'fro')^2+lambda*sum(abs(r(:)));
end

end

function W = updateW(W,A,B,maxItr2,eps2,stepMulp)
% Update W given suff. stats A, B and C

nItr = 0;
obj = zeros(1,maxItr2);
L = norm(A,'fro');
eta = 1/L*stepMulp;

while nItr <= 2 || (abs((obj(nItr)-obj(nItr-1))/obj(nItr-1)) > eps2 && nItr < maxItr2)
    W = projC(W - eta*(W*A-B));
    nItr = nItr + 1;
    obj(nItr) = 1/2*trace(W'*W*A) - trace(W'*B);
end

end
