function [W,H,R,obj] = BPGD_Solver(V, lambda, W, M, stepMulp, eps, maxItr)
% Batch robust NMF using PGD.
% Input:
% V: Data matrix (with outliers).
% lambda: regularization weight
% W: learned W from previous passes
% M: the max. value of entries of r
% stepMult: used to determine step sizes
% eps: the threshold for terminating iterations 
% maxItr: max. number of iterations 
% Output:
% W: learned basis matrix 
% H: learned coefficient matrix 
% R: learned outlier matrix 
% obj: sequence of objective values over iterations

% Copyright: Renbo Zhao (4 Oct 2016)

[F,N] = size(V);
K = size(W,2);

% Initialization
H = rand(K,N);    
R = rand(F,N);

nItr = 0;
obj = zeros(1,maxItr);

while  nItr <= 2 || (abs((obj(nItr)-obj(nItr-1))/obj(nItr-1)) > eps && nItr < maxItr)
    
    eta1 = 1/(norm(W,2)^2)*stepMulp;
    eta2 = 1/(norm(H*H','fro'))*stepMulp;
    H = max(H-eta1*W'*(W*H+R-V),0);
    R = softThresh2(V-W*H,lambda,M);
    W = projC(W-eta2*(W*H+R-V)*H');
    
    nItr = nItr + 1;
    obj(nItr) = 1/2*norm(V-W*H-R,'fro')^2 + lambda*sum(abs(R(:)));
    
end

end



