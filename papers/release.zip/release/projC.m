function W_proj = projC(W)
% Project each column of W onto the nonneg. \ell_2 ball

W_proj = max(W,0)/diag(max(sqrt(sum(W.^2,1)),1));

end

