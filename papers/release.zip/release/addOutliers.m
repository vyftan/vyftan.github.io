function dataNoisy = addOutliers(dataMat, density, percImg, lower, upper, isSave)
% Add outliers to each data sample and save results.
% Input:
% dataMat: data matrix
% density: outlier density in each image, in decimal
% percImg: proporation of images to be added outliers, in decimal
% lower, upper: lower and upper bounds for the entries of outliers
% isSave: flag to determine whether to save the generated data

% Copyright: Renbo Zhao (4 Oct 2016)

[n_pixel,n_img] = size(dataMat);

% Normalize data (max entry = 1)
dataMat = dataMat/max(max(dataMat));

% Shuffle dataset
dataMat = dataMat(:,randperm(n_img));

% Add Outliers
dataNoisy = dataMat;
numOutlier = floor(density*n_pixel);
for i = 1:floor(percImg*n_img)
    out_idx = randsample(n_pixel,numOutlier);
    outMat = zeros(n_pixel,1);
    outMat(out_idx) = round(rand(numOutlier,1)*(upper-lower)+lower); % outliers can only have integer magnitudes
    dataNoisy(:,i) = max(min(dataMat(:,i)+outMat,upper),0);          % project entries to [0,upper]
end

% Reshuffle dataset
dataNoisy = dataNoisy(:,randperm(n_img));

% Save results
if isSave
    disp('Saving noisy images...');
    fname = sprintf('synth_n%dp',density*100);
    eval([fname,'=dataNoisy;']);
    save(fname,fname);
end

end


