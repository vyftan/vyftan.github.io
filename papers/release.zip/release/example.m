% Example on a synthetic dataset
% Some tips:
% 1. Multipass extension is possible, just regard the dictionary learned
% in the previous pass as the initializer for the current pass.
% 2. Some parameters need to be tuned for optimal performances on specific
% datasets. These parameters include the step size in PGD, the
% regularization weight lambda, the mini-batch size, the latent dimension K etc.

% Copyright: Renbo Zhao (4 Oct 2016)

clear; close all; clc;

% Data Generation
F = 400;        % ambient data dimension
K = 49;         % latent dimension
N = 1e3;        % number of data samples
density = 0.2;  % density of outliers in one data sample
perc = 0.8;     % proportion of data samples to be contaminated by outliers
M = 1;          % upper-bound for the (entrywise) magnitudes of outliers
maxIter = 50;

disp('Generating data...');
W = abs(1/sqrt(K)*randn(F,K)); % iid Gaussian (var = 1/K)
H = abs(1/sqrt(K)*randn(K,N));
V0 = W*H;
V0 = V0/max(V0(:))*M;     % normalize to unit max norm
V = addOutliers(V0, density, perc, -M, M, true);

% Some parameters
mb_size = 5;
lambda = 1/sqrt(F);
rho1 = 1;
rho2 = 1;
rho3 = 1;
stepMulp = 0.7;
maxItr = 1e3;
maxItr1 = 1e2;
maxItr2 = 1e3;
eps = 1e-4;
eps1 = 1e-3;
eps2 = 1e-6;


W0 = rand(F,K);         % initialized W (to be distinguished from ground-truth W)
algo_set = {'OADMM', 'OPGD', 'BADMM', 'BPGD'};
for i = 1:length(algo_set)
    
    algo = algo_set{i};
    
    fprintf('Running %s...\n',algo);

    switch algo
        case 'OADMM'
            [W,H,R] = OADMM_Solver(V, lambda, mb_size, rho1, rho2, rho3, W0, M, maxItr1, maxItr2, eps1, eps2);
        case 'OPGD'
            [W,H,R] = OPGD_Solver(V, lambda, mb_size, W, M, stepMulp, maxItr1, maxItr2, eps1, eps2);
        case 'BADMM'
            [W,H,R,obj] = BADMM_Solver(V, lambda, rho1, rho2, rho3, W, M, eps, maxItr);
        case 'BPGD'
            [W,H,R,obj] = BPGD_Solver(V, lambda, W, M, stepMulp, eps, maxItr);
    end
    
end

