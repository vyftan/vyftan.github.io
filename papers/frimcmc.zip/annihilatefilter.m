%  
% [z, ztrue, zhat,t, error]=annihilatefilter(0);
% 
%   figure('Position',[1 400 400 300])
% 
% plot(t,ztrue, 'r', t, zhat, 'b--', 'Linewidth', 2);
% title('\sigma_e = 0, E = 4.49e-10');
% legend('z(t)', 'z_{est}(t)'); grid;
% axis([-20 20 -5 20])
% 
% [z, ztrue, zhat,t, error]=annihilatefilter(1e-6);
% 
% figure('Position',[1 400 400 300])
% 
% plot(t,ztrue, 'r', t, zhat, 'b--', 'Linewidth', 2);
% title('\sigma_e = 1e-6, E = 0.2721');
% legend('z(t)', 'z_{est}(t)'); grid; 
% axis([-20 20 -5 20])

function [z, ztrue, zhat, t,  error]=annihilatefilter(sigmaek)

% randn('state', 0);
% rand('state', 0);
% clear;clc;
ck=[6  12 10 15 9 ];
tk=[9  13 16 3 6 ]-10;
K=length(ck);
% sigmaek=0;
N=31;
n=linspace(0,20,N)-10;
T=n(2)-n(1);
z=zeros(length(n),1);
sigmah=1;
for k = 1:length(tk)
    z=z+ck(k)*gausskernel(n-tk(k),sigmah)';
end

% subplot(121); stem(n,z); title('Plot of clean z[n] against n');
% optobjfun=loglikelihood(ck,tk,sigmaek,z,n);
% Add noise
e=normrnd(0, sigmaek, length(z), 1);

y=z+e;

% subplot(122); stem(n,y); title('Plot of noisy y[n] against n ');

if(norm(z-y)~=0)
    snratio=20*log10(norm(z)/norm(z-y));
else 
    snratio=Inf;
end

X=(exp((n.^2)./(2*sigmah^2))).*z';
W=(exp((n.^2)./(2*sigmah^2))).*e';
Xtilde=(exp((n.^2)./(2*sigmah^2))).*y';

Xtildematrix=[];
Xmatrix=[];
Wmatrix=[];

for k = 0:N-(K+1)
   Xtildematrix=[Xtildematrix; Xtilde(1+k+K:-1:1+k)];
   Xmatrix=[Xmatrix; X(1+k+K:-1:1+k)];
      Wmatrix=[Wmatrix; W(1+k+K:-1:1+k)];
end

% [m,n]=size(Xtildematrix);
% for i = 1:m
%  %   length(W(i:i+K-1))
%     A(i)=1/(1/n*sum(W(i:i+K-1)));
% end
% for j = 1:n
% %    length(W(j:j+m-1))
%    B(j)=1/(1/m*sum(A(j)*W(j:j+m-1))); 
% end
% 
% A=diag(A); B=diag(B);
% 
% Xtildes=A*Xtildematrix*B;
% 
% [u,s,v]=svd(Xtildes);
% 
% 
% e_Kplus1=zeros(K+1,1);
% e_Kplus1(K+1)=1;
% 
% A=v*e_Kplus1;
% 
% u=roots(A);
% 
% tk_svd=sigmah^2*log(u)/T;
% tk_svd_real=real(tk_svd)

Smatrix=Xtildematrix;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[u,s,v]=svd(Smatrix);

e_Kplus1=zeros(K+1,1);
e_Kplus1(K+1)=1;

A=v*e_Kplus1;

u=roots(A);

tk_svd=sigmah^2*log(u)/T;
tk_svd_real=real(tk_svd)


Hmatrix=zeros(N,K);

for k = 1:K
    for nn=1:N
        Hmatrix(nn,k)=gausskernel(tk_svd_real(k)-n(nn),sigmah);
    end
end

ck_svd=Hmatrix\y;
ck_svd_real=real(ck_svd)

t = linspace(-12,12,100*N);
zhat=zeros(length(t),1);
ztrue=zeros(length(t),1);
for k = 1:length(tk)
    ztrue=ztrue+ck(k)*gausskernel(t-tk(k),sigmah)';
    zhat=zhat+ck_svd_real(k)*gausskernel(t-tk_svd_real(k),sigmah)';
end

% figure; 
% plot(t,ztrue, 'r', t, zhat, 'b');
% title('Plot of reconstructed z(t) and actual z(t)');
% legend('z(t)', 'z^{hat}(t)');

error=(norm(zhat-ztrue)/norm(ztrue))^2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[v1,d1]=eig(Smatrix'*Smatrix, 'nobalance');

A1=v1(:,1);

u1=roots(A1);

tk_eig=(sigmah^2)*log(u1)/T;
tk_eig_real=real(tk_eig)


