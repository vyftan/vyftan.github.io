N=50:25:125;
sigmae=1.5:.25:3;

Nseeds=100;
numiter=1500;
thisseed = sum(100*clock);
tic
for seed=1:Nseeds
    for n = 1:length(N)
        for e=1:length(sigmae)
            [error1(n,e, seed), error2(n,e, seed), snratio(n,e, seed), sigmahat(n,e, seed)] =...
                improvedgibbsfunc(N(n), sigmae(e), numiter,thisseed+10*seed);
        end
        n
    end
    seed
    toc
end
