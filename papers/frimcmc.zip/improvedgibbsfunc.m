function [error1, error2, snratio, sigmahat] = improvedgibbsfunc(N, sigmaek, numiter, seed)
% Actual values of ck and tk and sigmaek
randn('state',seed);
rand('state',seed);

ck=[6  12 10 15 9];%   13 16 9 10  11];
tk=[9  13 16 3 6 ];%   14 18 7 10 5];
K=length(ck);
% K=length(ck);

OversamplingFactor=N/(2*K+1);
n=linspace(0,20,N);
z=zeros(length(n),1);
sigmah=1;
for k = 1:length(tk)
    z=z+ck(k)*gausskernel(n-tk(k),sigmah)';
end

optobjfun=loglikelihood(ck,tk,sigmaek,z,n);
% Add noise
e=normrnd(0, sigmaek, length(z), 1);
y=z+e;

optobjfun=loglikelihood(ck,tk,sigmaek,z,n);

snratio=20*log10(norm(z)/norm(z-y));

% subplot(211); stem(n, z); title('(a) Clean signal z[n]');
% subplot(212); stem(n, y); title('(b) Noisy signal y[n]=z[n]+e[n]');

% c_0=0; c_1=0; c_2=0;
% t_0=0; t_1=0; t_2=0;
c=zeros(1,K);
% c=[6 12];
t=zeros(1,K);
% t=[10.5 13];
se=0.1;
thetaest=[c t se];
t_sampled=linspace(0,20,100);

y=y';
% numiter=200;
%scalefactor=10^(-.5);
scalefactor=1 ;

for iter = 1:numiter

    % Update c_k
    for k = 1:K

        alpha_0=(1/(2*se^2))*sum(exp(-((n-t(k)).^2)./(sigmah^2)));
        d=zeros(1,length(y));
        for kprime=1:K
            if(kprime ~= k)
                d=d+(c(kprime))*exp(-((n-t(kprime)).^2)./(2.*sigmah^2));
            end
        end

        beta_0=(1/(se^2))*sum((exp(-((n-t(k)).^2)./(2.*sigmah^2))).*(d-y));

        c(k)=normrnd(-beta_0/(2*alpha_0), sqrt(1/(2*alpha_0)));

    end

    % Update t_k
    for k = 1:K

        gamma_0=c(k)^2;

        d=zeros(1,length(y));
        for kprime=1:K
            if(kprime ~= k)
                d=(c(kprime))*exp(-((n-t(kprime)).^2)./(2.*sigmah^2))+d;
            end
        end

        delta=2*c(k)*(d-y);
        repn=repmat(n, length(t_sampled),1);
        repdelta=repmat(delta, length(t_sampled),1);
        rept_sampled=repmat(t_sampled', 1,N);

        lnprobs_t=-1/(2*se^2)*sum(gamma_0*exp(-((repn-rept_sampled).^2)./(sigmah^2))+ ...
            repdelta.*exp(-((repn-rept_sampled).^2)./(2*sigmah^2)),2);

        % Use discrete sampling
        %         for i = 1:length(t_sampled)
        %             lnprobs_t1(i)=-1/(2*se^2)*sum(gamma_0*exp(-((n-t_sampled(i)).^2)./(sigmah^2))+ ...
        %                 delta.*exp(-((n-t_sampled(i)).^2)./(2*sigmah^2)));
        %         end

        probs_t=exp(scalefactor*lnprobs_t)/sum(exp(scalefactor*lnprobs_t));
        %         figure; plot(t_sampled,probs_t)

        % Makes it faster
        %         if(iter>50)
        %             t_sampled_nonzero=t_sampled(probs_t>1e-16);
        %             probs_t_nonzeros=probs_t(probs_t>1e-16);

        % Implement rejection sampling here
        %             [m,maxindex]=max(probs_t_nonzeros);
        %             q=normpdf(t_sampled_nonzero, t_sampled_nonzero(maxindex), .3);
        %             q=q*m/max(q);
        %
        %             r=rand(1);
        %             rp=0; rq=1;
        %             if(length(find(q'-probs_t_nonzeros<-1e-2))~=0)
        %                 error('cq is not greater than p');
        %             end
        %
        %             while(r>rp/rq)
        %                 q_sample=normrnd(t_sampled_nonzero(maxindex), .3, 1);
        %                 rq=interp1(t_sampled_nonzero, q, q_sample,'linear','extrap');
        %                 rp=interp1(t_sampled_nonzero, probs_t_nonzeros, q_sample,'linear','extrap');
        %             end

        %             t(k)=q_sample;
        %             t(k)=discrete_sample(1, t_sampled_nonzero, probs_t_nonzeros);
        %         else
      if(norm(probs_t)==0)
          t(k)=rand(1)*20;
      else 
            t_sampled_nonzero=t_sampled;
            probs_t_nonzeros=probs_t;
            t(k)=discrete_sample(1, t_sampled_nonzero, probs_t_nonzeros);
      end
        %         end

    end

    % Update sigmae
    d=zeros(1,length(y));

    for kprime=1:K
        d=(c(kprime))*exp(-((n-t(kprime)).^2)./(2.*sigmah^2))+d;
    end

    psi=N/2;
    phi=2/sum((y - d).^2);
    se= (gamrnd(psi,phi))^(-.5);

    thetaest(iter,:) = [c  t  se];

%     drawnow;
%     subplot(321); plot(iter,c, 'rs', 'MarkerSize',2); hold on;   plot(iter, ck, 'bo', 'MarkerSize',2);
%     subplot(322); plot(iter,t, 'rs','MarkerSize',2); hold on;   plot(iter, tk, 'bo','MarkerSize',2);
%     subplot(3,2,3); plot(iter,se, 'rs','MarkerSize',2); hold on; plot(iter, sigmaek, 'bo','MarkerSize',2);
%     subplot(3,2,4); plot(iter,loglikelihood(c, t, se, y, n) , 'rs','MarkerSize',2); hold on;
    %     plot(iter, optobjfun, 'bo','MarkerSize',2);

    ll(iter)=loglikelihood(c,t,se,y,n);
end

% subplot(321); plot(thetaest(:,1:K), 'r-' ); hold on; plot(repmat(ck,numiter,1), 'b-');
% axis([0 numiter 0 max(ck)+2]);
% title('(a) c_k');
% subplot(322); plot(thetaest(:,K+1:2*K), 'r-'); hold on; plot(repmat(tk,numiter,1), 'b-');
% axis([0 numiter 0 max(tk)+2]); title('(b) t_k');
% subplot(3,2,3); plot(thetaest(:,end), 'r-'); hold on; plot(repmat(sigmaek,numiter,1), 'b-');
% title('(c) \sigma_e');
% axis([0 numiter 0 sigmaek+2]);
% subplot(3,2,4); plot(ll , 'r-'); %hold on; plot(repmat(optobjfun,numiter,1), 'b-');
% title('(d) -log(p)');
% axis([0 numiter min(ll )-10 max(ll )+10]);

mtheta=mean(thetaest(end-50:end,:));
ckhat=mtheta(1:K);
tkhat=mtheta(K+1:2*K);
sigmahat=mtheta(end);
time = linspace(-10,30,100*N);
zhat=zeros(length(time),1);
ztrue=zeros(length(time),1);
for k = 1:K
    ztrue=ztrue+ck(k)*gausskernel(time-tk(k),sigmah)';
    zhat=zhat+ckhat(k)*gausskernel(time-tkhat(k),sigmah)';
end
% subplot(325); plot(time, ztrue, 'b', time, zhat, 'r--'); axis([0 24 0 20]);
% % title('Plot of reconstructed z(t) and actual z(t)');
% legend('z(t)', 'z^{hat}(t)');

error1=(norm(zhat-ztrue)/norm(ztrue))^2;
% title(strcat('(e) MMSE error=',num2str(error1)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Hmatrix=zeros(N,K);

for k = 1:K
    for nn=1:N
        Hmatrix(nn,k)=gausskernel(tkhat(k)-n(nn),sigmah);
    end
end

ckhat2=Hmatrix\y';

zhat2=zeros(length(time),1);
for k = 1:K
    zhat2=zhat2+ckhat2(k)*gausskernel(time-tkhat(k),sigmah)';
end

% subplot(3,2,6); plot(time, ztrue, 'b', time, zhat2, 'r--'); axis([0 24 0 20]);
% legend('z(t)', 'z^{hat}(t)');

error2=(norm(zhat2-ztrue)/norm(ztrue))^2;
% title(strcat('(f) LLSE error=',num2str(error2)));
